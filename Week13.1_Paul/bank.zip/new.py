# Take an object from everyday life and model it in a class,
# giving it at least 3 attributes and 3 methods

class CanaCafea:
    def __init__(self, volum, material):
        self.volum = volum
        self.material = material
        self._continut = 0

    @property
    def continut(self):
        return self._continut

    @continut.setter
    def continut(self, value):
        self._continut += value
        if self._continut > 250:
            self._continut = 250
        if self._continut < 0:
            self._continut = 0

    def incarca_cana(self, cantitate):
        self.continut += cantitate

    def goleste_cana(self, cantitate):
        if self._continut - cantitate < 0:
            self._continut = 0
        else:
            self._continut -= cantitate

    def arata_continut(self):
        print(self._continut)


cana = CanaCafea(250, "ceramica")
cana.incarca_cana(300)
cana.arata_continut()
cana.goleste_cana(300)
cana.arata_continut()
